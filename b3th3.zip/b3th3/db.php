<?php
session_start();

// Kết nối CSDL
$conn = new mysqli('localhost','root','','test') or die('Kết nối thất bại');


$username = $_POST['username'];
$password = $_POST["password"];


// Chuẩn bị truy vấn SQL để kiểm tra thông tin đăng nhập
$sql = "SELECT * FROM tbl_account WHERE taiKhoan='$username' AND matKhau='$password'";
$result = mysqli_query($conn, $sql);

// Kiểm tra kết quả truy vấn
if (mysqli_num_rows($result) > 0) { //$result->num_rows
    $_SESSION['IsLogin'] = true;
$hashed_pass = sha1($password);

    echo "Mật khẩu sau khi mã hóa sha1 là: ".$hashed_pass;
    
} else {
    // Nếu thông tin đăng nhập không hợp lệ, redirect về trang login
    header("Location: login.html");
}

?>
